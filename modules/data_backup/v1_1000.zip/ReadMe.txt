# Data backup creator description :
# https://4pda.to/forum/index.php?showtopic=1014571&view=findpost&p=114462143

Мои разработки включают несколько проектов на xda и 4pda и некоторые спрашивают как меня поощрить, поэтому оставлю здесь:
Только на добровольной основе если кто желает поддержать меня за бессоные ночи, может пополнить баланс моего спец. мобильного телефоного на чашку кофе в 2..3$ :
+375 29 6454817   A1.BY  Беларусь. Пополнить баланс можно из почти любой страны мира, РФ, Укр,.. У большинства можно в своем банковском приложении, KIWI, и т.д.
Желательно сообщить об этом в личку 4pda. 
Вариант пополнения карты:
SWIFT: ZEPTBY2X
IBAN:  BY26ZEPT30140000505320118944
Спасибо за поддержку.

My development work on my many projects comes out of my free time, so if you enjoy some my project or anything else I have done. For a one-time donation you can hit the donate
to add few bucks for a cup of coffee to my cell phone balance: +375 29 6454817   A1.BY  Republic of Belarus. 
Or by wire to card :
SWIFT: ZEPTBY2X
IBAN:  BY26ZEPT30140000505320118944
Thank you for your support.
