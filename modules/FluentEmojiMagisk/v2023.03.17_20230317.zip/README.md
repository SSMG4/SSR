# Fluent Emoji Magisk Module

This is a Magisk module that replaces your Android system emojis with FluentUI Emojis systemlessly.

Fluent Emoji are a collection of familiar, friendly, and modern emoji from Microsoft.

![Fluent Emoji](readme_banner.webp)